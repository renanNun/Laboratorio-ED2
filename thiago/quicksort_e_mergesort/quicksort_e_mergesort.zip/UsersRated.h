#ifndef USERSRATED_H
#define USERSRATED_H

using namespace std;
class UsersRated {
    public:
        int id;
        int usersRated;
};

#endif // USERSRATED_H