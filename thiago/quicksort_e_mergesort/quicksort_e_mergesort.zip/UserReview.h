#ifndef USERREVIEW_H
#define USERREVIEW_H

#include <string>
using namespace std;
class UserReview {
    public:
        int id;
        string user;
        float rating;
};

#endif // USERREVIEW_H