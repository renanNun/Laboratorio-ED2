#include "UsersRated.h"

void mergeSort(UsersRated* vet,int inicio,int fim);
void intercala(UsersRated* vet,int inicio, int meio,int fim);