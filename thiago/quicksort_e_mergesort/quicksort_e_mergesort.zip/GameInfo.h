#ifndef GAMEINFO_H
#define GAMEINFO_H

#include <string>
#include <vector>
using namespace std;
class GameInfo {
    public:
        int id;
        vector<string> boardgamecategory;
};

#endif // GAMEINFO_H